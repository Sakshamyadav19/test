"""Auto-generated FlatBuffer bindings grouped by domain."""

__all__ = [
    "polygons",
    "shortcuts_uint8",
    "shortcuts_uint16",
]
