"""FlatBuffer schema definitions for timezonefinder."""

__all__ = [
    "polygons",
    "hybrid_shortcuts_uint8",
    "hybrid_shortcuts_uint16",
]
